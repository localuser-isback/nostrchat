import {Capacitor} from '@capacitor/core';
import {PaletteMode} from '@mui/material';
import {Channel, Platform, RelayDict} from 'types';

export const DEFAULT_RELAYS: RelayDict = {
    'wss://relay1.nostrchat.io': {read: true, write: true},
    'wss://relay2.nostrchat.io': {read: true, write: true},
    'wss://relay.damus.io': {read: true, write: true},
    'wss://relay.snort.social': {read: true, write: false},
    'wss://nos.lol': {read: true, write: true},
    'wss://relayable.org': {read: true, write: true},
};

export const MESSAGE_PER_PAGE = 30;
export const ACCEPTABLE_LESS_PAGE_MESSAGES = 5;
export const SCROLL_DETECT_THRESHOLD = 5;

export const GLOBAL_CHAT: Channel = {
    id: '12428bbd0e084ac3fd3ca6373d44fa409a725807f76ab8b4c33e228d96bde34e',
    name: 'Global Chat',
    about: 'Stellar Escape chatroom',
    picture: 'https://static.vecteezy.com/system/resources/previews/008/469/516/original/saturn-icon-on-white-background-vector.jpg',
    creator: 'npub1jtj3tdpsq495a6gc6wxespry99dncpmerm9jmvd0gep6g9g6nccsuet54e',
    created: 1678198928
};

export const PLATFORM = Capacitor.getPlatform() as Platform;

export const DEFAULT_THEME: PaletteMode = 'dark';